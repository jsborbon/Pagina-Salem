---
title: Genesis Hooks
menuTitle: Genesis Hooks
layout: layouts/base.njk
permalink: basics/genesis-hooks/index.html
tags: docs
---

Genesis Hooks are currently documented in your StudioPress account area:

<a href="https://my.studiopress.com/documentation/customization/guides-and-references/hook-reference/" class="button">View Genesis Hooks</a>

WP Engine customers who do not have a StudioPress account can find hook documentation in the [WP Engine User Portal](https://my.wpengine.com/themes/docs/customization/guides-and-references/hook-reference/).

We intend to migrate hook information here and ensure all hooks are documented.

